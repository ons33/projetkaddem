package tn.esprit.projet.entities;

public enum Specialite {
    IA,
    RESEAUX,
    CLOUD,
    SECURITE
}
