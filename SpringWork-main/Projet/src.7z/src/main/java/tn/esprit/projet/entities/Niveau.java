package tn.esprit.projet.entities;

public enum Niveau {
    JUNIOR,
    SENIOR,
    EXPERT
}
