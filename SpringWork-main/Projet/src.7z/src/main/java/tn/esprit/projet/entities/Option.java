package tn.esprit.projet.entities;

public enum Option {
    Gamix,
    SE,
    SIM,
    NIDS
}
